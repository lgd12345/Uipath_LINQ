package com.study;

public class UipathHello {
	
	int a = 100;
	
	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}
	
	public static String Addition(int a,int b)
	{
		int result = a + b;
		return result+"이다.";
	}
	public static int Substraction(int a,int b)
	{
		int result = a - b;
		return result;
	}

	
}
