package com.study;

public class RPARank {
	private int rank;
	private String message;
	private String latest;
	
	//생성자
	public RPARank(int r, String msg, String ver) {
		this.rank = r;
		this.latest = ver;
		this.message = msg;
	}
	
	public int getRank() {
		return this.rank;
	}

	public String getMessage() {
		return this.message;
	}

	public String getLatest() {
		return this.latest;
	}
	
	//객체를 문자열로 출력용
	@Override
	public String toString() {
		return "RPARank [rank= " + this.rank + ", message= " + this.message + ", latest= " + this.latest + "]";
	}
	

}
