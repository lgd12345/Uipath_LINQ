package com.study;

import java.util.HashMap;

public class Demo {

	private HashMap<String,RPARank> ranks;

	//생성자 객체 초기화,객체를 생성할때 자동호출
	public Demo() throws Exception {
		this.ranks = new HashMap<String, RPARank>();
		this.ranks.put("uipath",new RPARank(1,"2023.4.1","최신 FTS버전"));
	}
	
	// 특정키에 해당하는 RPARank 객체 반환
	// containsKey는 ranks 해시맵에 key가 존재하는지 여부확인
	// 하고 존재하면 수행하게 하기 위해서다. 
	public RPARank getRank(String key) {
		if(this.ranks.containsKey(key)) {
			return this.ranks.get(key);
		}
		else {
			return new RPARank(0, "", "키 값이 없습니다.");
		}
	}
	//특정키와 값으로 랭킹정보 추가갱신
	public void addRank(String key, RPARank val) {
		if(!this.ranks.containsKey(key)) {
			this.ranks.put(key, val);
		}
		else {
			this.ranks.replace(key, val);
		}
	}
	// 특정키에 대항하는 랭킹정보를 해시맵으로 반환
	public HashMap<String, String> getItem(String key){
		HashMap<String, String> map = new HashMap<String, String>();
		if(this.ranks.containsKey(key)) {
			RPARank item = this.ranks.get(key);
			map.put("rank", String.valueOf(item.getRank()));
			map.put("latest", String.valueOf(item.getMessage()));
			map.put("message", String.valueOf(item.getLatest()));
		} else {
			map.put("message", "값이 없습니다.");
		}
		return map;
	}
	//데모실행 main 메서드
	public static void main(String[] args) throws Exception {
		Demo demo = new Demo();
		System.out.println(demo.getRank("uipath"));
	}
	

}
